

egf=rgb2gray(imread('Image-1.tif')); %read in tifs and convert to grayscale

egfc=imadjust(egf); % auto-contrast images
figure, imshow(egfc);
[r, c]=ginput(8);%Number of points to draw ROI
BW= roipoly(egfc,r,c);
%figure, imshow(BW);

[R, C]=size(BW);

for i=1:R
    for j=1:C
        if BW(i,j)==1
            Out(i,j)=egfc(i,j);
             else
            Out(i,j)=0;
        end
    end
end

figure;
imshow(Out,[]);%Displays only ROI



Out3=uint8(Out);
BWegf=im2bw(Out3,0.96); %threshold EGF image to black and white
BW2egf=bwareafilt(BWegf,[1 2000]); % remove spots based on size


%Calculate area of detected particles
egf_prop = regionprops(BW2egf,'centroid','area'); % gets area of particles
[egf_spot, y]=size(egf_prop);

figure;
imshow(BW2egf);

disp(egf_spot)%value for area of total detected particles


%Get area of ROI
egf_A=[];
for i=1:length(egf_prop)
    egf_A=[egf_A,egf_prop(i).Area];
end
egf_area=sum(egf_A); %measures area of ROI

disp(egf_area)%Shows value for are of ROI
